<?php  

include "../Yassine/db_config.php";

$sql = "SELECT * FROM panier";
$result = mysqli_query($config, $sql)

?>