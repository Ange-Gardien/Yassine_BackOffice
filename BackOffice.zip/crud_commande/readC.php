<?php  

include "../Yassine/db_config.php";

$sql = "SELECT * FROM commande";
$result = mysqli_query($config, $sql)

?>